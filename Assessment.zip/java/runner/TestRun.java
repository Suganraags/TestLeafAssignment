package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="BonesFramework/src/main/java/features/createReport.feature", glue="BonesFramework/src/main/java/pages")
public class TestRun extends AbstractTestNGCucumberTests {

}
