package baseForProject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class baseClass {
	public static RemoteWebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver, 20);
	
	public RemoteWebDriver launchBrowser() {

		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(chromeOptions);
		driver.manage().window().maximize();
		return driver;
		
	}

	
	public RemoteWebDriver launchBrowser(String browser) {
		try { 
    
		System.out.println("Browser name is :" +browser );
		
		if(browser.equalsIgnoreCase("Chrome"))
		{
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(chromeOptions);
		driver.manage().window().maximize();
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			
		FirefoxOptions FirefoxOptions = new FirefoxOptions();
		FirefoxOptions.addPreference("dom.webnotifications.enabled", false);
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver(FirefoxOptions);	
		driver.manage().window().maximize();		    
		}
		
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
		return driver;
		
	}
	

	public void closeBrowser() {
		try {
		driver.close();	
		}
		catch(Exception e) 
		{
			System.out.println(e);
		}
	}

	public void quitBrowser() {
		try {
			driver.quit();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

	public void open(String aut) {
		try
		{
		
	    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    driver.get(aut);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	public WebElement getWebElement(String locator) {
		
		try {
		
		String[] ele = locator.split("=", 2);
		String locatorKey = ele[0];
		String locatorValue = ele[1];
		WebElement element = null;
	
		if(locatorKey.equalsIgnoreCase("ID")) {
			element = driver.findElementById(locatorValue);
		}
		else if(locatorKey.equalsIgnoreCase("NAME")) {
			element = driver.findElementByName(locatorValue);
		}
		else if(locatorKey.equalsIgnoreCase("CLASSNAME")) {
			element = driver.findElementByClassName(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("XPATH")) {
			element = driver.findElementByXPath(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("LINKTEXT")) {
			element = driver.findElementByLinkText(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("PARTIALLINKTEXT")) {
			element = driver.findElementByPartialLinkText(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("TAGNAME")) {
			element = driver.findElementByTagName(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("CSSSELECTOR")) {
			element = driver.findElementByCssSelector(locatorValue);
		}
		return element;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
		
		
	}

	public List<WebElement> getWebElements(String locator) {
		try {
		
		String[] arrayOfLocators = locator.split("=", 2);
		String locatorKey = arrayOfLocators[0];
		String locatorValue = arrayOfLocators[1];
		List<WebElement> element = null;
	
		if(locatorKey.equalsIgnoreCase("ID")) {
			element = driver.findElementsById(locatorValue);
		}
		else if(locatorKey.equalsIgnoreCase("NAME")) {
			element  = driver.findElementsByName(locatorValue);
		}
		else if(locatorKey.equalsIgnoreCase("CLASSNAME")) {
			element = driver.findElementsByClassName(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("XPATH")) {
			element = driver.findElementsByXPath(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("LINKTEXT")) {
			element = driver.findElementsByLinkText(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("PARTIALLINKTEXT")) {
			element = driver.findElementsByPartialLinkText(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("TAGNAME")) {
			element = driver.findElementsByTagName(locatorValue);
		}else if(locatorKey.equalsIgnoreCase("CSSSELECTOR")) {
			element = driver.findElementsByCssSelector(locatorValue);
		}
		return element;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
		
	}

	public void type(WebElement ele, String data) {
		try {
		
		ele.sendKeys(data);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	public void click(WebElement ele) {
		try {
		ele.click();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	public String getText(WebElement ele) {
		try {
		return ele.getText();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
		
	}

	
	public String getTitle() {
		try {
		
		return driver.getTitle();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
		
	}

	
	public void clearTextBox(WebElement ele) {
		try {
		ele.clear();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
