package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage extends baseClass {
	
	@When("Click on Applauncher icon")
	public HomePage ClickAppLauncher() {
		click(getWebElement("className=slds-icon-waffle"));
		return this;
	}
	
	@When("Click on View All link")
	public AppLauncher clickViewAll() throws InterruptedException {
		click(getWebElement("xpath=//button[text()='View All']"));
		Thread.sleep(3000);
		return new AppLauncher();

	}
	
	@Then("AppLauncher page should be displayed")
	public String CheckPageTitle()
	{
		String AppLauncherTitle = getTitle();
		System.out.println(AppLauncherTitle);
		return null;
	}

}
