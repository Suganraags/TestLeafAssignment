package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.Then;

public class UnsavedReport extends baseClass {
	
	@Then("Select Range as All Time")
	public UnsavedReport selectRange()
	{
		click(getWebElement("xpath=//input[@name='duration']//following::img"));
		click(getWebElement("xpath=//div[text()='All Time']"));
		return this;
	}

}
