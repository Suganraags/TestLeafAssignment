package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends baseClass {
	
	@And("enter username {string}")
	public LoginPage enterUsername(String Uname) {
		
		type(getWebElement("id=username"),Uname);
		return this;
	}
	
	@And("enter password {string}")
    public LoginPage enterPassword(String pswd) {
    	
    	type(getWebElement("id=password"),pswd);
		return this;
    	
    }
    
	@When("click Login button")
    public HomePage clickLogin() {
    	click(getWebElement("id=Login"));    	
    	return new HomePage();

	}
	
	@Then("Homepage will be displayed")
	public HomePage checkTitle()
	{
		String PageTitle = getTitle();
		System.out.println(PageTitle);
		return null;
	}
	
	
}
