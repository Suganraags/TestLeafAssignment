package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AppLauncher extends baseClass {
	
	@When("Service is searched in text box")
	public AppLauncher enterWorkType() throws InterruptedException {
		type(getWebElement("xpath=//label[text()='Search apps or items...']//following::div//input"), "Service");
		Thread.sleep(3000);
		return this;
	}
	
	@When("Service link is clicked")
	public Service clickService() {
		click(getWebElement("xpath=//*[text()='Service']"));
		return new Service();

	}
	
	@Then("Service link will be displayed")
	public String ServiceLinkVisible()
	{
		String linkName = getText(getWebElement("xpath=//*[text()='Service']"));
		System.out.println(linkName);
		return null;
	}
	
	

}
