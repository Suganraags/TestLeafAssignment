package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.Then;

public class Reports extends baseClass{
	
@Then("Click on New Report SalesForce Classic")
	public NewReport clickNewReport()
	{
		click(getWebElement("xpath=//div[text()='New Report (Salesforce Classic)']"));
		return new NewReport();
	}
}
