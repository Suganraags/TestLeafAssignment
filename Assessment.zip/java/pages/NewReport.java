package pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import baseForProject.baseClass;
import io.cucumber.java.en.Then;

public class NewReport extends baseClass{
	
	@Then("Click on Leads")
	public NewReport clickOnLeads()
	{
		click(getWebElement("xpath=//span[text()='Leads']"));
		return this;
	}
	
	@Then("Download the Lead Report Image on the Right side")
	public NewReport saveImageAs() throws AWTException, InterruptedException
	{
		//Locate Image
		WebElement LeadImage = getWebElement("xpath=//img[@src='/img/rptleadlist.gif']");
		//Right click on Image using contextClick() method.
		Actions action= new Actions(driver);
		action.contextClick(LeadImage).build().perform();
		//To perform press Ctrl + v keyboard button action.
		action.sendKeys(Keys.CONTROL, "v").build().perform();
		Thread.sleep(3000);
		  Robot robot = new Robot();
		  // To press D key.
		  robot.keyPress(KeyEvent.VK_D);
		  // To press : key.
		  robot.keyPress(KeyEvent.VK_SHIFT);
		  robot.keyPress(KeyEvent.VK_SEMICOLON);
		  robot.keyRelease(KeyEvent.VK_SHIFT);
		  // To press \ key.
		  robot.keyPress(KeyEvent.VK_BACK_SLASH);
		  // To press "test" key one by one.
		  robot.keyPress(KeyEvent.VK_L);
		  robot.keyPress(KeyEvent.VK_E);
		  robot.keyPress(KeyEvent.VK_A);
		  robot.keyPress(KeyEvent.VK_D);
		  // To press Save button.
		  robot.keyPress(KeyEvent.VK_ENTER);
		return this;
	}

	@Then("Click on Create")
	public UnsavedReport clickCreate() 
	{
		click(getWebElement("xpath=//input[@value='Create']"));
		return new UnsavedReport();
	}
}
