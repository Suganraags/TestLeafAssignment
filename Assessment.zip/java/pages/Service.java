package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.When;

public class Service extends baseClass {
	
	@When("Report tab is clicked")
	public Reports clickReportTab()
	{
		click(getWebElement("xpath = //span[text()='Reports']"));
		return new Reports();
	}

}
