package pages;

import baseForProject.baseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class GenericMethods extends baseClass {
	
	@Given("Launch chrome browser")
	public void startBrowser() {
		launchBrowser();

	}
	
	@Given("Load salesforce application url")
	public void loadUrl() {
		open("https://login.salesforce.com");
	}
	
	@Then("close the current browser")
	public void browserClose() {
		closeBrowser();

	}

}
